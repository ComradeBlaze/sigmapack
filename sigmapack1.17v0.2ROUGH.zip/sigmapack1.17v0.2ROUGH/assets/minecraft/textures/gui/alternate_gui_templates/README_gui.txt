In this folder I've included alternate files for various GUI elements since apparently some people hate my hotbar. Swap them out as needed. No warranty or tech support will be given.

- sigma_turbine
