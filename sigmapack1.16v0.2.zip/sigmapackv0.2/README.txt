Hi! This is SigmaPack, the crappiest texture pack known to man. 

I'm sigma_turbine, and I made this godawful piece of crap. I would say I'm proud of it but my ego would be hurt at such an accusation.

Despite its crappiness in certain aspects I wanted it to be somewhat usable as an actual pack. 

Some texture changes were made to fit me (and only me) so I included some alternative files in the GUI section; simply swap them out as needed.

Anyways, thanks for downloading this thing. Check the credits file for credits (isn't that nice?) and hope you enjoy it somehow.

- sigma_turbine (not responsible for any brain damage received)

================================================================================================================================================

NOTE: No warranties, either express or implied, are hereby given. All software is supplied as is, without guarantee.  The user assumes all

responsibility for damages resulting from the use of these features, including, but not limited to, frustration, disgust, system abends, disk

head-crashes, general malfeasance, floods, fires, shark attack, nerve gas, locust infestation, cyclones, hurricanes, tsunamis, local 

electromagnetic disruptions, hydraulic brake system failure, invasion, hashing collisions, normal wear and tear of friction surfaces, comic

radiation, inadvertent destruction of sensitive electronic components, windstorms, the Riders of Nazgul, infuriated chickens, malfunctioning

mechanical or electrical sexual devices, premature activation of the distant early warning system, peasant uprisings, halitosis, artillery

bombardment, explosions, cave-ins, and/or frogs falling from the sky.

